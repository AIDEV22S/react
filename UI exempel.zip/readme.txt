
1) skapa en react app med npx creat-react app demo1
2) gå till demo1 app med cd demo1
3) byt App.js i mappen src med befogad App.js 
4) starta server med npm 