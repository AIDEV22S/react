
1) skapa en react app med npx creat-react app demo1
2) gå till demo1 app med cd demo1
3) installera react-router-dom med npn install react-router-dom
4) byt App.js i mappen src med befogad App.js 
5) skapa mapparna pages och code med befogad
6) starta server med npm 