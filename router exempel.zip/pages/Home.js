function Home() {
  return <div>This is my Home Page</div>;
}

export default Home;
