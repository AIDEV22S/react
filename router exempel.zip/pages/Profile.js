function Profile() {
  return <div>THis is my Profile</div>;
}

export default Profile;
